// 数据库连接配置
module.exports = {
  mysql: {
    host: 'localhost',
    user: 'root',
    password: '80238023',
    database: 'myblog',
    port: '3306'
  }
}