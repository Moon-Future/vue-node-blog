<template>
  <div>
    <p>Hello, Nice to meet you !!!</p>
  </div>
</template>

<script>
export default {
  name: 'selfInfo'
}
</script>

<style lang="scss" scoped>
  
</style>

