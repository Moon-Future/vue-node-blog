<template>
  <div>
    <div class="crumbs">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item><i class="el-icon-date"></i> 表单</el-breadcrumb-item>
        <el-breadcrumb-item>User</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <el-upload
      action="https://jsonplaceholder.typicode.com/posts/">
      
    </el-upload>
  </div>
</template>

<script>
  export default {
    name: 'user'
  }
</script>

<style>

</style>
